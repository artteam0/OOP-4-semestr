﻿using System.Configuration;
using System.Data;
using System.Globalization;
using System.Windows;

namespace labs__oop_
{
    public partial class App : Application
    {
        public static CultureInfo CurrentLanguage { get; private set; }
        private static ResourceDictionary _languageDictionary;
        private static ResourceDictionary _themeDictionary;
        private static bool _isDarkTheme = false;

        private void Application_Startup(object sender, StartupEventArgs e)
        {
           // base.OnStartup(e);
            try
            {
                DatabaseHelper.InitializeDatabase();
                Console.WriteLine("Инициализация базы данных завершена.");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Критическая ошибка при инициализации базы данных: {ex.Message}", "Ошибка БД", MessageBoxButton.OK, MessageBoxImage.Error);
            }

            string systemLang = CultureInfo.CurrentUICulture.Name.ToLower();
            if (systemLang.StartsWith("ru"))
            {
                CurrentLanguage = new CultureInfo("ru-RU");
            }
            else
            {
                CurrentLanguage = new CultureInfo("en-US");
            }
            SetLanguage(CurrentLanguage);
            SetTheme(false);

            MainWindow mainWindow = new MainWindow();
            mainWindow.Show();
        }

        public static void SetLanguage(CultureInfo culture)
        {
            CurrentLanguage = culture;

            if (_languageDictionary != null)
            {
                Application.Current.Resources.MergedDictionaries.Remove(_languageDictionary);
            }

            _languageDictionary = new ResourceDictionary();
            string langFileName = culture.Name.Equals("ru-RU", StringComparison.OrdinalIgnoreCase) ? "ru-RU.xaml" : "en-US.xaml";
            _languageDictionary.Source = new Uri($"Locales/{langFileName}", UriKind.Relative);

            Application.Current.Resources.MergedDictionaries.Add(_languageDictionary);
        }

        public static void SetTheme(bool useDarkTheme)
        {
            _isDarkTheme = useDarkTheme;
            if (_themeDictionary != null)
            {
                Application.Current.Resources.MergedDictionaries.Remove(_themeDictionary);
            }

            _themeDictionary = new ResourceDictionary();
            string themeFileName = useDarkTheme ? "DarkTheme.xaml" : "LightTheme.xaml";
            _themeDictionary.Source = new Uri($"Themes/{themeFileName}", UriKind.Relative);

            Application.Current.Resources.MergedDictionaries.Add(_themeDictionary);
        }

        public static bool IsDarkTheme()
        {
            return _isDarkTheme;
        }
        public static string GetLocalizedString(string key)
        {
            if (_languageDictionary != null && _languageDictionary.Contains(key))
            {
                return _languageDictionary[key] as string;
            }
            return $"[{key}]";
        }
    }
}