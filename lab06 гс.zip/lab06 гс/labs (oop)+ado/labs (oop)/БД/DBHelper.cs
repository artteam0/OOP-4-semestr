﻿using System;
using System.Configuration;
using System.Data.SQLite;
using System.IO;

namespace labs__oop_
{
    public static class DatabaseHelper
    {
        private static readonly string DbFileName = ConfigurationManager.AppSettings["DatabaseFileName"] ?? "MyApplication2.db";
        public static string ConnectionString { get; } = ConfigurationManager.ConnectionStrings["DefaultConnection"]?.ConnectionString ?? $"Data Source={DbFileName};Version=3;";
        public static void InitializeDatabase()
        {
            if (!File.Exists(DbFileName))
            {
                SQLiteConnection.CreateFile(DbFileName);
               
                Console.WriteLine($"Файл базы данных '{DbFileName}' создан.");
            }
            using (var connection = GetConnection())
            {
                connection.Open();
                string createUsersTableScript = @"
                CREATE TABLE IF NOT EXISTS Users (
                    Id INTEGER PRIMARY KEY AUTOINCREMENT,
                    Name TEXT NOT NULL,
                    Age INTEGER NOT NULL,
                    Email TEXT NOT NULL UNIQUE,
                    ProfilePicture BLOB,
                    LastModified DATETIME DEFAULT CURRENT_TIMESTAMP
                );";
                string createRolesTableScript = @"
                CREATE TABLE IF NOT EXISTS Roles (
                    RoleId INTEGER PRIMARY KEY AUTOINCREMENT,
                    RoleName TEXT NOT NULL UNIQUE
                );";
                string createUserRolesTableScript = @"
                CREATE TABLE IF NOT EXISTS UserRoles (
                    UserId INTEGER,
                    RoleId INTEGER,
                    PRIMARY KEY (UserId, RoleId),
                    FOREIGN KEY (UserId) REFERENCES Users(Id) ON DELETE CASCADE,
                    FOREIGN KEY (RoleId) REFERENCES Roles(RoleId) ON DELETE CASCADE
                );";
                string triggerScript = @"
                CREATE TRIGGER IF NOT EXISTS UpdateUserLastModified
                AFTER UPDATE ON Users
                FOR EACH ROW
                BEGIN
                    UPDATE Users SET LastModified = CURRENT_TIMESTAMP WHERE Id = OLD.Id;
                END;";
                string seedRolesScript = @"
                INSERT OR IGNORE INTO Roles (RoleName) VALUES ('Administrator');
                INSERT OR IGNORE INTO Roles (RoleName) VALUES ('User');
                INSERT OR IGNORE INTO Roles (RoleName) VALUES ('Guest');";
                using (var command = new SQLiteCommand(connection))
                {
                    command.CommandText = createUsersTableScript;
                    command.ExecuteNonQuery();
                    Console.WriteLine("Таблица Users проверена/создана.");

                    command.CommandText = createRolesTableScript;
                    command.ExecuteNonQuery();
                    Console.WriteLine("Таблица Roles проверена/создана.");

                    command.CommandText = createUserRolesTableScript;
                    command.ExecuteNonQuery();
                    Console.WriteLine("Таблица UserRoles проверена/создана.");

                    command.CommandText = triggerScript;
                    command.ExecuteNonQuery();
                    Console.WriteLine("Триггер UpdateUserLastModified проверен/создан.");

                    command.CommandText = seedRolesScript;
                    command.ExecuteNonQuery();
                    Console.WriteLine("Начальные роли добавлены.");
                }
            }
        }
        public static SQLiteConnection GetConnection()
        {
            return new SQLiteConnection(ConnectionString);
        }
        public static void AddUserWithRole(User user, string roleName)
        {
            using (var connection = GetConnection())
            {
                connection.Open();
                using (var transaction = connection.BeginTransaction())
                {
                    try
                    {
                        string insertUserSql = "INSERT INTO Users (Name, Age, Email, ProfilePicture) VALUES (@Name, @Age, @Email, @ProfilePicture); SELECT last_insert_rowid();";
                        long userId;
                        using (var cmdUser = new SQLiteCommand(insertUserSql, connection, transaction))
                        {
                            cmdUser.Parameters.AddWithValue("@Name", user.Name);
                            cmdUser.Parameters.AddWithValue("@Age", user.Age);
                            cmdUser.Parameters.AddWithValue("@Email", user.Email);
                            cmdUser.Parameters.AddWithValue("@ProfilePicture", user.ProfilePicture ?? (object)DBNull.Value);
                            userId = (long)cmdUser.ExecuteScalar();
                        }
                        long? roleId = null;
                        string selectRoleSql = "SELECT RoleId FROM Roles WHERE RoleName = @RoleName;";
                        using (var cmdRole = new SQLiteCommand(selectRoleSql, connection, transaction))
                        {
                            cmdRole.Parameters.AddWithValue("@RoleName", roleName);
                            var result = cmdRole.ExecuteScalar();
                            if (result != null && result != DBNull.Value)
                            {
                                roleId = (long)result;
                            }
                        }
                        if (userId > 0 && roleId.HasValue)
                        {
                            string insertUserRoleSql = "INSERT INTO UserRoles (UserId, RoleId) VALUES (@UserId, @RoleId);";
                            using (var cmdUserRole = new SQLiteCommand(insertUserRoleSql, connection, transaction))
                            {
                                cmdUserRole.Parameters.AddWithValue("@UserId", userId);
                                cmdUserRole.Parameters.AddWithValue("@RoleId", roleId.Value);
                                cmdUserRole.ExecuteNonQuery();
                            }
                        }
                        else if (!roleId.HasValue)
                        {
                            Console.WriteLine($"Предупреждение: Роль '{roleName}' не найдена. Пользователь добавлен без этой роли.");
                        }

                        transaction.Commit();
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        Console.WriteLine($"Ошибка в AddUserWithRole: {ex.Message}");
                        throw;
                    }
                }
            }
        }
    }
}