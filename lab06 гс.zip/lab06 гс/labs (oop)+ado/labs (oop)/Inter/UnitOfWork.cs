﻿using labs__oop_.Inter;
using labs__oop_.Repositories;
using System;
using System.Data.SQLite;
using labs__oop_.Inter;
namespace labs__oop_.UnitOfWork
{
    public class SqliteUnitOfWork : IDisposable
    {
        private SQLiteConnection _connection;
        private SQLiteTransaction _transaction;
        private bool _disposed = false;
        private IRepository<User> _userRepository;
        private IUserRepository _users;

        public SqliteUnitOfWork()
        {
            _connection = new SQLiteConnection(DatabaseHelper.ConnectionString);
            _connection.Open();
            _transaction = _connection.BeginTransaction();
        }
        public IUserRepository Users
        {
            get
            {
                if (_users == null)
                {
                    _users = new UserRepository(_connection, _transaction);
                }
                return _users;
            }
        }
        public void SaveChanges()
        {
            if (_transaction == null)
            {
                throw new InvalidOperationException("Транзакция не активна.");
            }
            try
            {
                _transaction.Commit();
            }
            catch
            {
                _transaction.Rollback();
                throw;
            }
            finally
            {
                if (_transaction != null)
                {
                    _transaction.Dispose();
                    _transaction = null;
                }
            }
        }
        public void Rollback()
        {
            if (_transaction != null && _transaction.Connection != null)
            {
                try
                {
                    _transaction.Rollback();
                }
                finally
                {
                    _transaction.Dispose();
                    _transaction = null;
                }
            }
        }


        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        protected virtual void Dispose(bool disposing)
        {
            if (!_disposed)
            {
                if (disposing)
                {
                    if (_transaction != null)
                    {
                        try
                        {
                            _transaction.Rollback();
                        }
                        catch (Exception ex)
                        {
                            Console.WriteLine($"Ошибка при автоматическом откате транзакции в Dispose: {ex.Message}");
                        }
                        finally
                        {
                             _transaction.Dispose();
                             _transaction = null;
                        }
                    }
                    if (_connection != null)
                    {
                        _connection.Close();
                        _connection.Dispose();
                        _connection = null;
                    }
                }
                _disposed = true;
            }
        }

        ~SqliteUnitOfWork()
        {
            Dispose(false);
        }
    }
}