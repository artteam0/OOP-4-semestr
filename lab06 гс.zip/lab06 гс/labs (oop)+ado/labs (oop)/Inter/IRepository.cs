﻿using System;
using System.Collections.Generic;
using System.Linq.Expressions;

namespace labs__oop_.Repositories
{
    public interface IRepository<TEntity> where TEntity : class 
    {
        TEntity GetById(int id);
        IEnumerable<TEntity> GetAll(string sortBy = null, bool ascending = true);
        IEnumerable<TEntity> Find(Func<TEntity, bool> predicate);

        void Add(TEntity entity);
        void Update(TEntity entity);
        void Delete(int id);
        void Delete(TEntity entity);
    }
}