﻿using System;
using labs__oop_.Repositories;

namespace labs__oop_.UnitOfWork
{
    public interface IUnitOfWork : IDisposable
    {
        IRepository<User> Users { get; }
        void SaveChanges();
    }
}