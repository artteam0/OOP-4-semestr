﻿using labs__oop_.Repositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace labs__oop_.Inter
{
    public interface IUserRepository : IRepository<User>
    {
        IEnumerable<User> SearchByName(string searchTerm);
    }
}
