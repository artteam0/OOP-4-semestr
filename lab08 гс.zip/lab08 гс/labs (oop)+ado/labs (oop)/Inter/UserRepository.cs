﻿using System;
using System.Collections.Generic;
using System.Data.SQLite;
using System.Linq;
using labs__oop_.Inter;
namespace labs__oop_.Repositories
{
    public class UserRepository : IUserRepository
    {
        private readonly SQLiteConnection _connection;
        private readonly SQLiteTransaction _transaction;
        public UserRepository(SQLiteConnection connection, SQLiteTransaction transaction)
        {
            _connection = connection ?? throw new ArgumentNullException(nameof(connection));
            _transaction = transaction;

        }

        public User GetById(int id)
        {
            User user = null;
            string sql = "SELECT Id, Name, Age, Email, ProfilePicture, LastModified FROM Users WHERE Id = @Id";

            using (var command = new SQLiteCommand(sql, _connection, _transaction))
            {
                command.Parameters.AddWithValue("@Id", id);
                using (var reader = command.ExecuteReader())
                {
                    if (reader.Read())
                    {
                        user = MapUserFromReader(reader);
                    }
                }
            }
            return user;
        }

        public IEnumerable<User> GetAll(string sortBy = "Name", bool ascending = true)
        {
            var users = new List<User>();
            string sortOrder = ascending ? "ASC" : "DESC";
            if (string.IsNullOrWhiteSpace(sortBy) || !IsValidSortColumn(sortBy))
            {
                sortBy = "Name";
            }
            string sql = $"SELECT Id, Name, Age, Email, ProfilePicture, LastModified FROM Users ORDER BY {sortBy} {sortOrder}";

            using (var command = new SQLiteCommand(sql, _connection, _transaction))
            {
                using (var reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        users.Add(MapUserFromReader(reader));
                    }
                }
            }
            return users;
        }
        public IEnumerable<User> Find(Func<User, bool> predicate)
        {
            return GetAll().Where(predicate);
        }
        public IEnumerable<User> SearchByName(string searchTerm)
        {
            var users = new List<User>();
            string sql = "SELECT Id, Name, Age, Email, ProfilePicture, LastModified FROM Users WHERE Name LIKE @SearchTerm ORDER BY Name";
            using (var command = new SQLiteCommand(sql, _connection, _transaction))
            {
                command.Parameters.AddWithValue("@SearchTerm", $"%{searchTerm}%");
                using (var reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        users.Add(MapUserFromReader(reader));
                    }
                }
            }
            return users;
        }


        public void Add(User entity)
        {
            if (entity == null) throw new ArgumentNullException(nameof(entity));
            string sql = "INSERT INTO Users (Name, Age, Email, ProfilePicture) VALUES (@Name, @Age, @Email, @ProfilePicture); SELECT last_insert_rowid();";
            using (var command = new SQLiteCommand(sql, _connection, _transaction))
            {
                command.Parameters.AddWithValue("@Name", entity.Name);
                command.Parameters.AddWithValue("@Age", entity.Age);
                command.Parameters.AddWithValue("@Email", entity.Email);
                command.Parameters.AddWithValue("@ProfilePicture", entity.ProfilePicture ?? (object)DBNull.Value);

                object result = command.ExecuteScalar();
                if (result != null && result != DBNull.Value)
                {
                    entity.Id = Convert.ToInt32(result);
                }
            }
        }

        public void Update(User entity)
        {
            if (entity == null) throw new ArgumentNullException(nameof(entity));
            string sql = "UPDATE Users SET Name = @Name, Age = @Age, Email = @Email, ProfilePicture = @ProfilePicture WHERE Id = @Id";
            using (var command = new SQLiteCommand(sql, _connection, _transaction))
            {
                command.Parameters.AddWithValue("@Name", entity.Name);
                command.Parameters.AddWithValue("@Age", entity.Age);
                command.Parameters.AddWithValue("@Email", entity.Email);
                command.Parameters.AddWithValue("@ProfilePicture", entity.ProfilePicture ?? (object)DBNull.Value);
                command.Parameters.AddWithValue("@Id", entity.Id);
                int rowsAffected = command.ExecuteNonQuery();
                if (rowsAffected == 0)
                {
                    Console.WriteLine($"Warning: User with Id {entity.Id} not found for update or no data changed.");
                }
            }
        }

        public void Delete(int id)
        {
            string sql = "DELETE FROM Users WHERE Id = @Id";
            using (var command = new SQLiteCommand(sql, _connection, _transaction))
            {
                command.Parameters.AddWithValue("@Id", id);
                int rowsAffected = command.ExecuteNonQuery();
                if (rowsAffected == 0)
                {
                    Console.WriteLine($"Warning: User with Id {id} not found for deletion.");
                }
            }
        }

        public void Delete(User entity)
        {
            if (entity == null) throw new ArgumentNullException(nameof(entity));
            Delete(entity.Id);
        }
        private User MapUserFromReader(SQLiteDataReader reader)
        {
            return new User
            {
                Id = reader.GetInt32(reader.GetOrdinal("Id")),
                Name = reader.GetString(reader.GetOrdinal("Name")),
                Age = reader.GetInt32(reader.GetOrdinal("Age")),
                Email = reader.GetString(reader.GetOrdinal("Email")),
                ProfilePicture = reader.IsDBNull(reader.GetOrdinal("ProfilePicture")) ? null : (byte[])reader.GetValue(reader.GetOrdinal("ProfilePicture")),
                LastModified = reader.GetDateTime(reader.GetOrdinal("LastModified"))
            };
        }

        private bool IsValidSortColumn(string columnName)
        {
            var validColumns = new List<string> { "Id", "Name", "Age", "Email", "LastModified" };
            return validColumns.Contains(columnName, StringComparer.OrdinalIgnoreCase);
        }
    }
}