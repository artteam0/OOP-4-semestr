﻿using labs__oop_.Repositories;
using labs__oop_.UnitOfWork;
using Microsoft.Win32;
using System;
using System.Collections;
using System.Collections.ObjectModel; 
using System.ComponentModel;
using System.Data.SQLite;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text.RegularExpressions;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media.Imaging;

namespace labs__oop_
{
    public partial class MainWindow : Window, INotifyPropertyChanged
    {
        private ObservableCollection<User> _usersCollection;
        private User _selectedUser;
        private byte[] _currentProfilePictureBytes;
        private Stack<User> _undoStack = new Stack<User>();
        private Stack<User> _redoStack = new Stack<User>();
        private User _currentUserStateBeforeEdit;
        private bool _isPopulatingForm = false;
        private void PopulateFormForEdit()
        {
            _isPopulatingForm = true;
            try
            {
                if (SelectedUser != null)
                {
                    _currentUserStateBeforeEdit = new User
                    {
                        Id = SelectedUser.Id,
                        Name = SelectedUser.Name,
                        Age = SelectedUser.Age,
                        Email = SelectedUser.Email,
                        ProfilePicture = SelectedUser.ProfilePicture?.ToArray(),
                        LastModified = SelectedUser.LastModified
                    };
                    _undoStack.Clear();
                    _redoStack.Clear();
                    UpdateUndoRedoButtonStates();


                    NameTextBox.Text = SelectedUser.Name;
                    AgeTextBox.Text = SelectedUser.Age.ToString();
                    EmailTextBox.Text = SelectedUser.Email;
                    _currentProfilePictureBytes = SelectedUser.ProfilePicture;
                    ClearErrors();
                }
                else
                {
                    _currentUserStateBeforeEdit = null;
                    _undoStack.Clear();
                    _redoStack.Clear();
                    UpdateUndoRedoButtonStates();
                }
            }
            finally
            {
                _isPopulatingForm = false;
            }
        }
        private void PushCurrentFormStateToUndoStack()
        {
            if (_selectedUser == null) return;

            var currentState = new User
            {
                Id = _selectedUser.Id,
                Name = NameTextBox.Text,
                Age = int.TryParse(AgeTextBox.Text, out int age) ? age : _selectedUser.Age,
                Email = EmailTextBox.Text,
                ProfilePicture = _currentProfilePictureBytes,
                LastModified = _selectedUser.LastModified 
            };
            if (_undoStack.Count > 0)
            {
                var previousState = _undoStack.Peek();
                if (AreUsersEqual(previousState, currentState)) return;
            }
            else if (_currentUserStateBeforeEdit != null && AreUsersEqual(_currentUserStateBeforeEdit, currentState))
            {
                return; 
            }


            _undoStack.Push(currentState);
            _redoStack.Clear();
            UpdateUndoRedoButtonStates();
        }
        private bool AreUsersEqual(User u1, User u2)
        {
            if (u1 == null || u2 == null) return u1 == u2;
            return u1.Name == u2.Name &&
                   u1.Age == u2.Age &&
                   u1.Email == u2.Email &&
                   StructuralComparisons.StructuralEqualityComparer.Equals(u1.ProfilePicture, u2.ProfilePicture);
        }


        private void UndoButton_Click(object sender, RoutedEventArgs e)
        {
            if (_undoStack.Count > 0)
            {
                var formStateToRedo = new User
                {   Id = SelectedUser.Id,
                    Name = NameTextBox.Text,
                    Age = int.TryParse(AgeTextBox.Text, out int age) ? age : SelectedUser.Age,
                    Email = EmailTextBox.Text,
                    ProfilePicture = _currentProfilePictureBytes
                };
                _redoStack.Push(formStateToRedo);

                User previousState = _undoStack.Pop();
                ApplyStateToForm(previousState);
                _selectedUser.Name = previousState.Name; 
                _selectedUser.Age = previousState.Age;
                _selectedUser.Email = previousState.Email;
                _selectedUser.ProfilePicture = previousState.ProfilePicture;
                _currentProfilePictureBytes = previousState.ProfilePicture;


                UpdateUndoRedoButtonStates();
            }
        }

        private void RedoButton_Click(object sender, RoutedEventArgs e)
        {
            if (_redoStack.Count > 0)
            {
                var formStateToUndo = new User
                { 
                    Id = SelectedUser.Id,
                    Name = NameTextBox.Text,
                    Age = int.TryParse(AgeTextBox.Text, out int age) ? age : SelectedUser.Age,
                    Email = EmailTextBox.Text,
                    ProfilePicture = _currentProfilePictureBytes
                };
                _undoStack.Push(formStateToUndo);

                User nextState = _redoStack.Pop();
                ApplyStateToForm(nextState);
                _selectedUser.Name = nextState.Name;
                _selectedUser.Age = nextState.Age;
                _selectedUser.Email = nextState.Email;
                _selectedUser.ProfilePicture = nextState.ProfilePicture;
                _currentProfilePictureBytes = nextState.ProfilePicture;

                UpdateUndoRedoButtonStates();
            }
        }

        private void ApplyStateToForm(User state)
        {
            _isPopulatingForm = true;
            try
            {
                NameTextBox.Text = state.Name;
                AgeTextBox.Text = state.Age.ToString();
                EmailTextBox.Text = state.Email;
                _currentProfilePictureBytes = state.ProfilePicture;
                ProfilePictureBox.Source = ByteArrayToImageSourceConverter.ConvertBytesToImageSource(state.ProfilePicture);
            }
            finally
            {
                _isPopulatingForm = false;
            }
        }

        private void UpdateUndoRedoButtonStates()
        {
            UndoButton.IsEnabled = _undoStack.Count > 0;
            RedoButton.IsEnabled = _redoStack.Count > 0;
        }
        private void NameTextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (_isPopulatingForm || SelectedUser == null) return;
        }
        public ObservableCollection<User> UsersCollection
        {
            get => _usersCollection;
            set { _usersCollection = value; OnPropertyChanged(nameof(UsersCollection)); }
        }

        public User SelectedUser
        {
            get => _selectedUser;
            set
            {
                _selectedUser = value;
                OnPropertyChanged(nameof(SelectedUser));
                PopulateFormForEdit();
            }
        }

        public MainWindow()
        {
            InitializeComponent();
            DataContext = this;
            //_userDataService = new UserDataService();
            LoadUsers();
            UpdateChangeLangButtonText();
            UpdateUndoRedoButtonStates();
        }

        private void UpdateChangeLangButtonText()
        {
            if (App.CurrentLanguage.Name.Equals("ru-RU", StringComparison.OrdinalIgnoreCase))
            {
                ChangeLangButton.Content = App.GetLocalizedString("LangSwitchToEn");
            }
            else
            {
                ChangeLangButton.Content = App.GetLocalizedString("LangSwitchToRu");
            }
        }

        private void ChangeLangButton_Click(object sender, RoutedEventArgs e)
        {
            CultureInfo newCulture;
            if (App.CurrentLanguage.Name.Equals("ru-RU", StringComparison.OrdinalIgnoreCase))
            {
                newCulture = new CultureInfo("en-US");
            }
            else
            {
                newCulture = new CultureInfo("ru-RU");
            }
            App.SetLanguage(newCulture);
            UpdateChangeLangButtonText();
            ClearErrors();
        }

        private void ChangeThemeButton_Click(object sender, RoutedEventArgs e)
        {
            App.SetTheme(!App.IsDarkTheme());
        }

        private void LoadUsers(string sortBy = "Name", bool ascending = true)
        {
            try
            {
                using (var uow = new SqliteUnitOfWork())
                {
                    var usersList = uow.Users.GetAll(sortBy, ascending).ToList();
                    UsersCollection = new ObservableCollection<User>(usersList);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error loading users: {ex.Message}", "Database Error", MessageBoxButton.OK, MessageBoxImage.Error);
                UsersCollection = new ObservableCollection<User>();
            }
        }

        private bool ValidateForm(bool isUpdateOperation = false)
        {
            ClearErrors();
            bool isValid = true;

            if (string.IsNullOrWhiteSpace(NameTextBox.Text))
            {
                NameErrorTextBlock.Text = App.GetLocalizedString("ErrorNameRequired");
                isValid = false;
            }
            else if (NameTextBox.Text.Length < 2)
            {
                NameErrorTextBlock.Text = App.GetLocalizedString("ErrorNameMinLength");
                isValid = false;
            }

            if (string.IsNullOrWhiteSpace(AgeTextBox.Text))
            {
                AgeErrorTextBlock.Text = App.GetLocalizedString("ErrorAgeRequired");
                isValid = false;
            }
            else if (!int.TryParse(AgeTextBox.Text, out int age))
            {
                AgeErrorTextBlock.Text = App.GetLocalizedString("ErrorAgeNumeric");
                isValid = false;
            }
            else if (age < 0 || age > 120)
            {
                AgeErrorTextBlock.Text = App.GetLocalizedString("ErrorAgeRange");
                isValid = false;
            }

            if (string.IsNullOrWhiteSpace(EmailTextBox.Text))
            {
                EmailErrorTextBlock.Text = App.GetLocalizedString("ErrorEmailRequired");
                isValid = false;
            }
            else
            {
                string emailPattern = @"^[^@\s]+@[^@\s]+\.[^@\s]+$";
                if (!Regex.IsMatch(EmailTextBox.Text, emailPattern))
                {
                    EmailErrorTextBlock.Text = App.GetLocalizedString("ErrorEmailInvalid");
                    isValid = false;
                }
            }
            return isValid;
        }

        private void ClearErrors()
        {
            NameErrorTextBlock.Text = string.Empty;
            AgeErrorTextBlock.Text = string.Empty;
            EmailErrorTextBlock.Text = string.Empty;
            ImageErrorTextBlock.Text = string.Empty;
        }

        private void ClearForm()
        {
            NameTextBox.Text = string.Empty;
            AgeTextBox.Text = string.Empty;
            EmailTextBox.Text = string.Empty;
            ProfilePictureBox.Source = null;
            _currentProfilePictureBytes = null;
            SelectedUser = null;
            UsersDataGrid.SelectedItem = null;
            ClearErrors();
        }

        private void ClearFormButton_Click(object sender, RoutedEventArgs e)
        {
            ClearForm();
        }
        private void BrowseImageButton_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog
            {
                Filter = "Image files (*.png;*.jpeg;*.jpg;*.bmp)|*.png;*.jpeg;*.jpg;*.bmp|All files (*.*)|*.*",
                Title = "Select a Profile Picture"
            };

            if (openFileDialog.ShowDialog() == true)
            {
                try
                {
                    _currentProfilePictureBytes = File.ReadAllBytes(openFileDialog.FileName);
                    BitmapImage bitmap = new BitmapImage();
                    bitmap.BeginInit();
                    bitmap.UriSource = new Uri(openFileDialog.FileName);
                    bitmap.CacheOption = BitmapCacheOption.OnLoad;
                    bitmap.EndInit();
                    ProfilePictureBox.Source = bitmap;
                    ImageErrorTextBlock.Text = "";
                }
                catch (Exception ex)
                {
                    _currentProfilePictureBytes = null;
                    ProfilePictureBox.Source = null;
                    ImageErrorTextBlock.Text = App.GetLocalizedString("ErrorImageLoad");
                    MessageBox.Show($"Error loading image: {ex.Message}", "Image Error", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
        }
        private void AddButton_Click(object sender, RoutedEventArgs e)
        {
            PushCurrentFormStateToUndoStack();
            if (ValidateForm())
            {
                var newUser = new User
                {
                    Name = NameTextBox.Text,
                    Age = int.Parse(AgeTextBox.Text),
                    Email = EmailTextBox.Text,
                    ProfilePicture = _currentProfilePictureBytes
                };

                try
                {
                    using (var uow = new SqliteUnitOfWork())
                    {
                        uow.Users.Add(newUser);
                        uow.SaveChanges();                         }
                    MessageBox.Show(App.GetLocalizedString("UserAddedSuccess"), App.GetLocalizedString("SuccessTitle"), MessageBoxButton.OK, MessageBoxImage.Information);
                    LoadUsers();
                    ClearForm();
                }
                catch (SQLiteException sqlEx) when (sqlEx.ErrorCode == 19 && sqlEx.Message.ToLower().Contains("email"))
                {
                    EmailErrorTextBlock.Text = App.GetLocalizedString("ErrorEmailExists");
                    MessageBox.Show(App.GetLocalizedString("ErrorEmailExists"), App.GetLocalizedString("ErrorTitle"), MessageBoxButton.OK, MessageBoxImage.Error);
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error adding user: {ex.Message}", App.GetLocalizedString("ErrorTitle"), MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
            // ...
        }

        private void UpdateButton_Click(object sender, RoutedEventArgs e)
        {
            PushCurrentFormStateToUndoStack();
            if (SelectedUser == null) { return; }
            if (ValidateForm(isUpdateOperation: true))
            {
                SelectedUser.Name = NameTextBox.Text;
                SelectedUser.Age = int.Parse(AgeTextBox.Text);
                SelectedUser.Email = EmailTextBox.Text;
                if (_currentProfilePictureBytes != null && !StructuralComparisons.StructuralEqualityComparer.Equals(_currentProfilePictureBytes, SelectedUser.ProfilePicture))
                {
                    SelectedUser.ProfilePicture = _currentProfilePictureBytes;
                }

                try
                {
                    using (var uow = new SqliteUnitOfWork())
                    {
                        uow.Users.Update(SelectedUser);
                        uow.SaveChanges();
                    }
                    MessageBox.Show(App.GetLocalizedString("UserUpdatedSuccess"), App.GetLocalizedString("SuccessTitle"), MessageBoxButton.OK, MessageBoxImage.Information);
                    LoadUsers();
                    ClearForm();
                }
                catch (SQLiteException sqlEx) when (sqlEx.ErrorCode == 19 && sqlEx.Message.ToLower().Contains("email"))
                {
                    EmailErrorTextBlock.Text = App.GetLocalizedString("ErrorEmailExists");
                    MessageBox.Show(App.GetLocalizedString("ErrorEmailExists"), App.GetLocalizedString("ErrorTitle"), MessageBoxButton.OK, MessageBoxImage.Error);
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error updating user: {ex.Message}", App.GetLocalizedString("ErrorTitle"), MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
            else
            {
                MessageBox.Show(App.GetLocalizedString("ValidationError"), App.GetLocalizedString("ErrorTitle"), MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
        private void DeleteButton_Click_FromGrid(object sender, RoutedEventArgs e)
        {
            if (sender is Button deleteButton && deleteButton.CommandParameter is int userId)
            {
                var result = MessageBox.Show(App.GetLocalizedString("ConfirmDeleteMessage"),
                                             App.GetLocalizedString("ConfirmDeleteTitle"),
                                             MessageBoxButton.YesNo, MessageBoxImage.Warning);
                if (result == MessageBoxResult.Yes)
                {
                    try
                    {
                        using (var uow = new SqliteUnitOfWork())
                        {
                            uow.Users.Delete(userId);
                            uow.SaveChanges();
                        }
                        MessageBox.Show(App.GetLocalizedString("UserDeletedSuccess"), App.GetLocalizedString("SuccessTitle"), MessageBoxButton.OK, MessageBoxImage.Information);
                        LoadUsers();
                        if (SelectedUser?.Id == userId) ClearForm();
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show($"Error deleting user: {ex.Message}", App.GetLocalizedString("ErrorTitle"), MessageBoxButton.OK, MessageBoxImage.Error);
                    }
                }
            }
        }
        private void UsersDataGrid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (UsersDataGrid.SelectedItem is User selectedGridItem)
            {
                if (_selectedUser == null || _selectedUser.Id != selectedGridItem.Id)
                {
                    User fullUser = null;
                    try
                    {
                        using (var uow = new SqliteUnitOfWork())
                        {
                            fullUser = uow.Users.GetById(selectedGridItem.Id);
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show($"Error getting user details: {ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                    }
                    SelectedUser = fullUser;
                }
            }
        }
        private void SearchButton_Click(object sender, RoutedEventArgs e)
        {
            PerformSearch();
        }
        private void SearchTextBox_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                PerformSearch();
            }
        }

        private void PerformSearch()
        {
            string searchTerm = SearchTextBox.Text;
            if (string.IsNullOrWhiteSpace(searchTerm))
            {
                LoadUsers();
            }
            else
            {
                try
                {
                    using (var uow = new SqliteUnitOfWork())
                    {
                        var usersList = uow.Users.SearchByName(searchTerm).ToList();
                        UsersCollection = new ObservableCollection<User>(usersList);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error searching users: {ex.Message}", "Search Error", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
        }
        private void LoadAllButton_Click(object sender, RoutedEventArgs e)
        {
            SearchTextBox.Text = "";
            LoadUsers();
        }

        public event PropertyChangedEventHandler PropertyChanged;
        protected virtual void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}