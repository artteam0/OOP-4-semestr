﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data.SQLite;
using System.Linq;

namespace labs__oop_
{
    public class UserDataService
    {
        public int AddUser(User user)
        {
            using (var connection = DatabaseHelper.GetConnection())
            {
                connection.Open();
                using (var transaction = connection.BeginTransaction())
                {
                    try
                    {
                        string sql = "INSERT INTO Users (Name, Age, Email, ProfilePicture) VALUES (@Name, @Age, @Email, @ProfilePicture); SELECT last_insert_rowid();";
                        using (var command = new SQLiteCommand(sql, connection, transaction))
                        {
                            command.Parameters.AddWithValue("@Name", user.Name);
                            command.Parameters.AddWithValue("@Age", user.Age);
                            command.Parameters.AddWithValue("@Email", user.Email);
                            command.Parameters.AddWithValue("@ProfilePicture", user.ProfilePicture ?? (object)DBNull.Value);

                            object result = command.ExecuteScalar();
                            transaction.Commit();
                            return (int)(long)result;
                        }
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        Console.WriteLine($"Ошибка при добавлении пользователя: {ex.Message}");
                        throw; 
                    }
                }
            }
        }
        public ObservableCollection<User> GetAllUsers(string sortBy = "Name", bool ascending = true)
        {
            var users = new ObservableCollection<User>();
            string sortOrder = ascending ? "ASC" : "DESC";

            if (string.IsNullOrWhiteSpace(sortBy) || !IsValidSortColumn(sortBy))
            {
                sortBy = "Name";
            }
            string sql = $"SELECT Id, Name, Age, Email, ProfilePicture, LastModified FROM Users ORDER BY {sortBy} {sortOrder}";

            using (var connection = DatabaseHelper.GetConnection())
            {
                connection.Open();
                using (var command = new SQLiteCommand(sql, connection))
                {
                    using (var reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            users.Add(new User
                            {
                                Id = reader.GetInt32(0),
                                Name = reader.GetString(1),
                                Age = reader.GetInt32(2),
                                Email = reader.GetString(3),
                                ProfilePicture = reader.IsDBNull(4) ? null : (byte[])reader.GetValue(4),
                                LastModified = reader.GetDateTime(5)
                            });
                        }
                    }
                }
            }
            return users;
        }
        private bool IsValidSortColumn(string columnName)
        {
            var validColumns = new List<string> { "Id", "Name", "Age", "Email", "LastModified" };
            return validColumns.Contains(columnName, StringComparer.OrdinalIgnoreCase);
        }
        public User GetUserById(int id)
        {
            User user = null;
            string sql = "SELECT Id, Name, Age, Email, ProfilePicture, LastModified FROM Users WHERE Id = @Id";

            using (var connection = DatabaseHelper.GetConnection())
            {
                connection.Open();
                using (var command = new SQLiteCommand(sql, connection))
                {
                    command.Parameters.AddWithValue("@Id", id);
                    using (var reader = command.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            user = new User
                            {
                                Id = reader.GetInt32(0),
                                Name = reader.GetString(1),
                                Age = reader.GetInt32(2),
                                Email = reader.GetString(3),
                                ProfilePicture = reader.IsDBNull(4) ? null : (byte[])reader.GetValue(4),
                                LastModified = reader.GetDateTime(5)
                            };
                        }
                    }
                }
            }
            return user;
        }
        public bool UpdateUser(User user)
        {
            using (var connection = DatabaseHelper.GetConnection())
            {
                connection.Open();
                using (var transaction = connection.BeginTransaction())
                {
                    try
                    {
                        string sql = "UPDATE Users SET Name = @Name, Age = @Age, Email = @Email, ProfilePicture = @ProfilePicture WHERE Id = @Id";
                        using (var command = new SQLiteCommand(sql, connection, transaction))
                        {
                            command.Parameters.AddWithValue("@Name", user.Name);
                            command.Parameters.AddWithValue("@Age", user.Age);
                            command.Parameters.AddWithValue("@Email", user.Email);
                            command.Parameters.AddWithValue("@ProfilePicture", user.ProfilePicture ?? (object)DBNull.Value);
                            command.Parameters.AddWithValue("@Id", user.Id);
                            int rowsAffected = command.ExecuteNonQuery();
                            transaction.Commit();
                            return rowsAffected > 0;
                        }
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        Console.WriteLine($"Ошибка при обновлении пользователя: {ex.Message}");
                        throw;
                    }
                }
            }
        }
        public bool DeleteUser(int id)
        {
            using (var connection = DatabaseHelper.GetConnection())
            {
                connection.Open();
                using (var transaction = connection.BeginTransaction())
                {
                    try
                    {
                        string sqlDeleteUser = "DELETE FROM Users WHERE Id = @Id";
                        using (var command = new SQLiteCommand(sqlDeleteUser, connection, transaction))
                        {
                            command.Parameters.AddWithValue("@Id", id);
                            int rowsAffected = command.ExecuteNonQuery();
                            transaction.Commit();
                            return rowsAffected > 0;
                        }
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        Console.WriteLine($"Ошибка при удалении пользователя: {ex.Message}");
                        throw;
                    }
                }
            }
        }
        public ObservableCollection<User> SearchUsersByName(string searchTerm)
        {
            var users = new ObservableCollection<User>();
            string sql = "SELECT Id, Name, Age, Email, ProfilePicture, LastModified FROM Users WHERE Name LIKE @SearchTerm ORDER BY Name";

            using (var connection = DatabaseHelper.GetConnection())
            {
                connection.Open();
                using (var command = new SQLiteCommand(sql, connection))
                {
                    command.Parameters.AddWithValue("@SearchTerm", $"%{searchTerm}%");
                    using (var reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            users.Add(new User
                            {
                                Id = reader.GetInt32(0),
                                Name = reader.GetString(1),
                                Age = reader.GetInt32(2),
                                Email = reader.GetString(3),
                                ProfilePicture = reader.IsDBNull(4) ? null : (byte[])reader.GetValue(4),
                                LastModified = reader.GetDateTime(5)
                            });
                        }
                    }
                }
            }
            return users;
        }
    }
}